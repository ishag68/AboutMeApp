//
//  AboutMeAppApp.swift
//  AboutMeApp
//
//  Created by Isha Gunisetti on 7/13/23.
//

import SwiftUI

@main
struct AboutMeAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
